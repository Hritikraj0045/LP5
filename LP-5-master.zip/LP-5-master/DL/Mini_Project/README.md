https://github.com/smahesh29/Gender-and-Age-Detection
